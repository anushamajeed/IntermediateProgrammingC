/* Anusha Majeed 
   1001582645
   CSE 1320-003
   ASCII Drawing Tool - Coding Assignment 3
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "DrawTool.h"


int main (void)
{
	int DrawArr[MAX_ARRAY][MAX_ARRAY]={};
	int userInputSize;
	char userStr[MAX_ARRAY];
	int rowcheck, colcheck;
	char outb;
	
	Map(DrawArr, &userInputSize);
	instructions();
	PrintMap(DrawArr, userInputSize);
		
	printf("\n\nEnter draw command (enter Q to quit)\n");
	fgets(userStr, MAX_ARRAY-1, stdin);
	
	char direc = *(strtok(userStr,"(,)")); 
	direc = toupper(direc);
	
	int row, col, spots;
	char mark;
		
	while(direc != 'Q')
	{
		if(direc != 'P' && direc != 'V' && direc != 'H') 
		{
			printf("\nThat is not a draw command. Enter a new draw command.\n");
		
		}
		else
		{	
			outb = 'N'; //no error
			row = atoi(strtok(NULL, "(,)"));
			col = atoi(strtok(NULL, "(,)"));
			spots = atoi(strtok(NULL, "(,)"));
			mark = *(strtok(NULL, "(,)"));
		
			if(direc == 'P')
			{
				spots =0;
			}
			if(row >= userInputSize)
			{
				outb = 'Y';//error
			}
			if(col >= userInputSize)
			{
				outb = 'Y';
			}
			
		
			//check if coordinates are out of bounds
			if(direc == 'V')
			{
				if(row >= userInputSize)
				{
					outb = 'Y';//false
				}
				if(col >= userInputSize)
				{
					outb = 'Y';
				}
				rowcheck = (row + spots)-1;
				colcheck=0;
			}
		
			if(direc == 'H')
			{
				if(row >= userInputSize)
				{
					outb = 'Y';//false
				}
				if(col >= userInputSize)
				{
					outb = 'Y';
				}
				colcheck = (col + spots)-1;
				rowcheck=0;
			}
		
		
			if(rowcheck >= userInputSize)
			{
				outb = 'Y';
			}
			if(colcheck >= userInputSize)
			{
				outb='Y';
			}
			
			if(outb == 'N')
			{
				DrawLines(DrawArr,userInputSize,row,col,spots,mark,direc);
				PrintMap(DrawArr, userInputSize);
			}
			else 
			{
				printf("\nCoordinates out of range and lines drawn past the borders are not allowed.\n");
			}
		}
		printf("\n\nEnter draw command (enter Q to quit)\n");
		fgets(userStr, MAX_ARRAY-1, stdin);
		direc = *(strtok(userStr, "(,)")); 
		direc = toupper(direc);
	}
}
