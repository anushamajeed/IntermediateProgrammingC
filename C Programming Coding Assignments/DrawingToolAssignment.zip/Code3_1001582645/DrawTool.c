/*
Anusha Majeed
1001582645
Coding Assignment 3 - ASCII Drawing Tool
CSE 1320-003
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "DrawTool.h"

//Initialize map function 
void Map(int DrawArr[MAX_ARRAY][MAX_ARRAY], int *userInputSize)
{
	int i, j;
	char backgroundChar;
	
	printf("How big is the array? (Enter a value between 1 and 20) ");
	scanf("%d", userInputSize);
	printf("\n");
	
	while(*userInputSize < 1 || *userInputSize > MAX_ARRAY)
	{
		printf("The value you entered is out of range. Please enter a new value.");
		scanf("%d", userInputSize);
	}
	
	printf("What is the background character? ");
	scanf(" %c", &backgroundChar);

	
	//set backgroundChar to array 
	for(i = 0; i <*userInputSize; i++)
	{
		for(j = 0; j <*userInputSize; j++)
		{
			*(*(DrawArr + i) + j) = backgroundChar;
		}
	}	
}

//Print instructions function
void instructions()
{
	printf("\n\nDraw commands start with\n\n\n");
	printf("\t P for a single point\n\n");
	printf("\t H for a horiztonal line\n\n");
	printf("\t V for a vertical line\n\n");
	
	printf("After the P/V/H, enter a row,col coordinate and the number of spots to mark\n");
	printf("enclosed in () and separated by commas and then the character for the mark.\n");
	printf("'X' will be used if a mark is not entered. For example,\n\n\n");
	printf("\t P(2,3,1)*	start at point 2,3 in the array and mark one spots\n");
	printf("\t			with an * For P, the 3rd parameter is ignored.\n\n");
	printf("\t V(1,2,3)$	start at point 1,2 in the array and mark the next\n");
	printf("\t			3 spots down from the current position with $\n\n");
	printf("\t H(4,6,7)#	start at point 4,6 in the array and mark the next\n");
	printf("\t			7 spots to the right with #\n\n");
	
	printf("Coordinates out of range and lines drawn past the borders are not allowed.\n\n");
	printf("Enter Q at the draw command prompt to quit\n\n");
	printf("Press <ENTER> to continue");
	getchar();
	getchar();
}

//Print map function
void PrintMap(int DrawArr[MAX_ARRAY][MAX_ARRAY], int userInputSize)
{
	int i, j;
	printf("\n\n");
	for(i = 0; i < userInputSize; i++)
	{
		printf("\n");
		for(j = 0; j <userInputSize; j++)
		{
			printf(" %c ", *(*(DrawArr + i) + j));
		}
	}
}

//function to draw lines
void DrawLines(int DrawArr[][MAX_ARRAY],int userInputSize, int row, int col, int spots, char mark, char direc)
{
	int i;
	
	if(mark == '\n')
	{
		mark = 'X';
	}
	
	if(direc == 'P')
	{
		spots = 0;
		*(*(DrawArr + row) + col) = mark;
	}
	else if (direc == 'V')
	{
		for(i = row; i < (spots + row); i++)
		{
			*(*(DrawArr + i) + col) = mark;	
		}
		
	}
	else if(direc == 'H')
	{
		for(i = col; i < (spots + col); i++)
		{
			*(*(DrawArr + row) + i) = mark;	
		}
	}
}
