/*
Anusha Majeed
1001582645
Coding Assignment 3 - ASCII Drawing Tool
CSE 1320-003
*/

#ifndef _DrawTool_
#define _DrawTool_

#define MAX_ARRAY 20

void Map(int DrawArr[MAX_ARRAY][MAX_ARRAY], int *userInputSize);
void instructions();
void PrintMap(int DrawArr[MAX_ARRAY][MAX_ARRAY], int userInputSize);
void DrawLines(int DrawArr[][MAX_ARRAY], int userInputSize, int row, int col, int spots, char mark, char direc);

#endif
