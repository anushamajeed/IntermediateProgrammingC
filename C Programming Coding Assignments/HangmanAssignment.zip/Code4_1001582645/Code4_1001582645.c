/*
Anusha Majeed
1001582645
Coding Assignment 4
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "GameLib.h"

int main(int argc, char *argv[])
{
	FILE *ReadFH;
	AWARD award[MAX_ENTRIES];
	int recordcount=0;
	char readfilename[100] = {};
	int mchoice;
	
	
	ReadFH = OpenAwardFile(argc, argv, award);
	
	recordcount = FillAwardArray(ReadFH, award);
	
	printf("Welcome to the Academy Awards Guessing Game\n\n");
	
	while(1)
	{
		mchoice = PrintAwardMenu(award, recordcount);
		if(mchoice == 0)
			exit(0);
		GuessIt(award, mchoice);
	}	
}
