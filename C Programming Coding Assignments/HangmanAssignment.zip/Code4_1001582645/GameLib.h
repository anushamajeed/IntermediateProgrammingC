/*
Anusha Majeed
1001582645
Coding Assignment 4
GameLib.h
*/
#ifndef _GameLib_
#define _GameLib_

#define MAX_ENTRIES 15

typedef struct
{
	char year[3];
	char *cat;
	char *win;
} AWARD;

FILE* OpenAwardFile(int argc, char *argv[], AWARD award[]);
int FillAwardArray(FILE *ReadFH, AWARD award[]);
int PrintAwardMenu(AWARD award[], int recordcount);
void GuessIt(AWARD *award, int mchoice);

#endif
