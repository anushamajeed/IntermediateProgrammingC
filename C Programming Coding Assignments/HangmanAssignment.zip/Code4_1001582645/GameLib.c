/*
Anusha Majeed
1001582645
Coding Assignment 4
GameLib.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "GameLib.h"

//open file award function
FILE* OpenAwardFile(int argc, char *argv[], AWARD award[])
{
	FILE *ReadFH;
	char readfilename[100] = {};
	
	if(argc == 2)
	{
		strcpy(readfilename, argv[1]);
		strtok(readfilename, "\n");
	}
	else
	{
		printf("No input file found on command line\n");
		printf("Enter a file name at the prompt\n");
		scanf("%s", readfilename); 
		printf("\n\n");
	}
	
	ReadFH = fopen(readfilename, "r");
	
	//verify file opens
	while(ReadFH == NULL)
	{
		ReadFH = fopen(readfilename, "r");
		if(ReadFH == NULL)
		{
			printf("could not open file\n");
			printf("Enter a file name at the prompt\n");
			scanf("%s", readfilename); 
			
			ReadFH = fopen(readfilename, "r");
		}
	}	
	return ReadFH;
}

//fill award array function
int FillAwardArray(FILE *ReadFH, AWARD award[])
{
	int recordcount=0;
	char *token;
	char buffer[100];
	//ReadFH = fopen(readfilename, "r");
	
	while((fgets(buffer, sizeof(buffer)-1, ReadFH)))
	{
		token = strtok(buffer, "|");
		strcpy(award[recordcount].year, token);
		
		token = strtok(NULL, "|");
		award[recordcount].cat = malloc(strlen(token)*sizeof(char));
		strcpy(award[recordcount].cat, token);
		
		token = strtok(NULL, "|");
		award[recordcount].win = malloc(strlen(token)*sizeof(char));
		strcpy(award[recordcount].win, token);
		
		recordcount++;
	}
	
	return recordcount;
}

//print award menu function
int PrintAwardMenu(AWARD award[], int recordcount)
{
	int i;
	int mchoice=1;
	
	printf("0. Exit\n\n");
	for(i = 0; i < recordcount; i++)
	{
		printf("%d. %s %s\n\n",i+1, award[i].year, award[i].cat);
	}
	
	
		printf("Pick a category\n");
		scanf("%d", &mchoice);
		printf("\n");
	
	
		
		if(mchoice == 0)
		{
			printf("Game over\n");
			exit(0);
		}
	
		while(mchoice < 0 || mchoice > 5)
		{
			printf("Invalid menu option. Please select a new option.\n");
			scanf("%d", &mchoice);
			printf("\n");
		}
	
	return mchoice;
}

//guess it function
void GuessIt(AWARD *award, int mchoice)
{
	int j,d;
	srand(time(0));
	int random = rand();
	int winl = (strlen(award->win))/2;
	int guesses = ((random%winl)+3);
	char guess;
	char *check;
	char upcp1[100];
	char dashcp2[100];
	char alpha[]= "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	int dashcount=0;
	
	
	
	printf("You have %d guesses.\n\n", guesses);
	//printf("%s %s\n\n", award[mchoice-1].year, award[mchoice-1].cat);
	
	strcpy(upcp1, award[mchoice-1].win);
	strcpy(dashcp2, award[mchoice-1].win);
	
	
	
	//printf("%s\n", award[mchoice-1].win);
	
	for(j =0; j < strlen(upcp1)-1; j++)
	{
		upcp1[j] = toupper(upcp1[j]);
	}
	
	
	char *var;
	var = strpbrk(dashcp2, alpha);
	
	while(var != NULL)
	{
		*var = '-';
		var =strpbrk(dashcp2, alpha);
		dashcount++;
	}
	
	
	//printf("%s\n", dashcp2);

	
	while(guesses != 0 || check == NULL)
	{
		printf("Player: Guess a letter: \n");
		scanf(" %c", &guess);
		
		guess = toupper(guess);
		var = strchr(upcp1, guess);
		
		if(var == NULL)
		{
			guesses = guesses -1;
			printf("You have %d guesses left.\n\n", guesses);
		}
		else
		{
			while(var!= NULL)
			{
			d = abs(upcp1-var);
			dashcp2[d] = upcp1[d];
			upcp1[d] = '-';
			dashcount--;
			
			var = strchr(upcp1, guess);
			}
			printf("%s\n", dashcp2);
		}
		
		if(dashcount ==0)
			break;
	}
	
	
	check = strchr(dashcp2, '-');
	
	if(check == NULL)
	{
		printf("You win!\n");
		printf("The winner of the %s %s was %s\n",award[mchoice-1].year, award[mchoice-1].cat, award[mchoice-1].win);
		
	}
	else if(guesses == 0)
	{
		printf("You are out of guesses. You lose.\n");
	}
	return;
}
